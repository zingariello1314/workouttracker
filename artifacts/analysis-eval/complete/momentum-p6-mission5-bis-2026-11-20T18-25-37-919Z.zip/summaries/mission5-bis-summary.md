# Mission 5 bis — synthèse rejeu

Exécuté : 2026-11-20T18:25:37.919Z
Édition : consolidation=narrative-coherence-v2;duration=paired-density-v3;editorial=p6-sovereign-v6;gtg=classic-exclusive-v1;identity=discovery-occurrence-v1;program=structural-adherence-v1;review=collective-pass4-v3;scope=short-window-anchor-v1;stimulus=challenge-unknown-v1;streak=window-range-v1;temporal=calendar-paris-v1
Complet : true
Jeu C 8 périodes : FAIL
Doublons exacts accessibles : 0
Admissible préservé (ids) : false

## Horizons
- today: produit=6 prio=6 réserve=0 publié=6 autorité=p6 lostSilent=0 A=false B=true C=true (4637ms)
- 7d: produit=52 prio=11 réserve=27 publié=38 autorité=p6 lostSilent=0 A=false B=true C=true (4464ms)
- 30d: produit=73 prio=11 réserve=46 publié=57 autorité=p6 lostSilent=0 A=true B=true C=false (5694ms)
- 3m: produit=94 prio=11 réserve=66 publié=77 autorité=p6 lostSilent=0 A=true B=false C=false (7505ms)
- 6m: produit=100 prio=11 réserve=72 publié=83 autorité=p6 lostSilent=0 A=false B=false C=false (7760ms)
- 1y: produit=92 prio=11 réserve=73 publié=84 autorité=p6 lostSilent=0 A=false B=false C=false (8182ms)
- 2y: produit=90 prio=11 réserve=73 publié=84 autorité=p6 lostSilent=0 A=false B=false C=false (9508ms)
- all: produit=88 prio=11 réserve=71 publié=82 autorité=p6 lostSilent=0 A=false B=false C=false (7898ms)

## Artefacts manquants dans ce ZIP
- `eight-periods/eight-periods.json` — export live UI non exécuté dans cet ZIP hors-navigateur — lancer Récap→Analyse→Exporter le dossier d’audit complet après chargement du bridge
- `evaluation/dom-eight-periods.json` — navigateur authentifié non exercé ici — bouton « Vérifier les 8 périodes (DOM) » puis ré-export
- `evaluation/live/game-*.json` — jeux live session UI absents de cet assemblage hors-navigateur
- `human-blind-verdict.json` — aucune validation humaine à l’aveugle n’a été effectuée

> Aucune validation humaine à l’aveugle n’a été effectuée.
