# Mission 5 bis — synthèse rejeu

Exécuté : 2026-11-21T02:09:02.048Z
Édition : consolidation=narrative-coherence-v3;duration=paired-density-v3;editorial=p6-sovereign-v7;gtg=classic-exclusive-v1;identity=discovery-occurrence-v1;program=structural-reasoning-v1;review=collective-pass4-v4;scope=short-window-anchor-v1;stimulus=challenge-unknown-v1;streak=window-range-v1;temporal=calendar-paris-v1
Complet : true
Jeu C 8 périodes : FAIL
Doublons exacts accessibles : 14
Admissible préservé (ids) : true

## Horizons
- today: produit=6 prio=3 réserve=3 publié=6 autorité=p6 lostSilent=0 A=false B=false C=true (7666ms)
- 7d: produit=53 prio=11 réserve=30 publié=41 autorité=p6 lostSilent=0 A=false B=false C=false (7208ms)
- 30d: produit=74 prio=11 réserve=49 publié=60 autorité=p6 lostSilent=0 A=false B=false C=false (9113ms)
- 3m: produit=93 prio=11 réserve=67 publié=78 autorité=p6 lostSilent=0 A=false B=false C=false (13664ms)
- 6m: produit=99 prio=11 réserve=73 publié=84 autorité=p6 lostSilent=0 A=false B=false C=false (13773ms)
- 1y: produit=92 prio=11 réserve=75 publié=86 autorité=p6 lostSilent=0 A=false B=false C=false (14581ms)
- 2y: produit=90 prio=11 réserve=75 publié=86 autorité=p6 lostSilent=0 A=false B=false C=false (17195ms)
- all: produit=88 prio=11 réserve=73 publié=84 autorité=p6 lostSilent=0 A=false B=false C=false (16302ms)

## Artefacts manquants dans ce ZIP
- `eight-periods/eight-periods.json` — export live UI non exécuté dans cet ZIP hors-navigateur — lancer Récap→Analyse→Exporter le dossier d’audit complet après chargement du bridge
- `evaluation/dom-eight-periods.json` — navigateur authentifié non exercé ici — bouton « Vérifier les 8 périodes (DOM) » puis ré-export
- `evaluation/live/game-*.json` — jeux live session UI absents de cet assemblage hors-navigateur
- `human-blind-verdict.json` — aucune validation humaine à l’aveugle n’a été effectuée

> Aucune validation humaine à l’aveugle n’a été effectuée.
