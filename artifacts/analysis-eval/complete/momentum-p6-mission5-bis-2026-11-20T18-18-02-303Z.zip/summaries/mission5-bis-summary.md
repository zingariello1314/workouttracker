# Mission 5 bis — synthèse rejeu

Exécuté : 2026-11-20T18:18:02.303Z
Édition : consolidation=narrative-coherence-v2;duration=paired-density-v3;editorial=p6-sovereign-v6;gtg=classic-exclusive-v1;identity=discovery-occurrence-v1;program=structural-adherence-v1;review=collective-pass4-v3;scope=short-window-anchor-v1;stimulus=challenge-unknown-v1;streak=window-range-v1;temporal=calendar-paris-v1
Complet : true
Jeu C 8 périodes : FAIL
Doublons exacts accessibles : 0
Admissible préservé (ids) : false

## Horizons
- today: produit=6 prio=6 réserve=0 publié=6 autorité=p6 lostSilent=0 A=false B=true C=true (5088ms)
- 7d: produit=51 prio=11 réserve=26 publié=37 autorité=p6 lostSilent=0 A=false B=true C=true (5261ms)
- 30d: produit=72 prio=11 réserve=45 publié=56 autorité=p6 lostSilent=0 A=true B=true C=false (5686ms)
- 3m: produit=93 prio=11 réserve=65 publié=76 autorité=p6 lostSilent=0 A=true B=false C=false (7838ms)
- 6m: produit=99 prio=11 réserve=71 publié=82 autorité=p6 lostSilent=0 A=false B=false C=false (7930ms)
- 1y: produit=91 prio=11 réserve=72 publié=83 autorité=p6 lostSilent=0 A=false B=false C=false (7844ms)
- 2y: produit=89 prio=11 réserve=72 publié=83 autorité=p6 lostSilent=0 A=false B=false C=false (9146ms)
- all: produit=87 prio=11 réserve=70 publié=81 autorité=p6 lostSilent=0 A=false B=false C=false (8062ms)

## Artefacts manquants dans ce ZIP
- `eight-periods/eight-periods.json` — export live UI non exécuté dans cet ZIP hors-navigateur — lancer Récap→Analyse→Exporter le dossier d’audit complet après chargement du bridge
- `evaluation/dom-eight-periods.json` — navigateur authentifié non exercé ici — bouton « Vérifier les 8 périodes (DOM) » puis ré-export
- `evaluation/live/game-*.json` — jeux live session UI absents de cet assemblage hors-navigateur
- `human-blind-verdict.json` — aucune validation humaine à l’aveugle n’a été effectuée

> Aucune validation humaine à l’aveugle n’a été effectuée.
